const Colors = {
    accent500: "#ff6b6b",
    accent800: "#ee5a6f",
    primary300: "#2c3e50",
    primary500: "#ff9f43",
    primary800: "#ffffff",
};

export default Colors;